import { useState } from 'react';
import {
  LayoutDashboard,
  Users,
  Settings as SettingsIcon,
  Play,
  Square,
  Download,
  Search,
  Menu,
  X,
  Bell,
  MessageSquare,
  ShieldCheck,
  Zap,
  Activity,
  Globe,
  Plus,
  RefreshCw,
  Trash2,
  Key,
  ChevronRight,
  TrendingUp,
  FileText
} from 'lucide-react';
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';

/* ───────── Types ───────── */
interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  active: boolean;
  onClick: () => void;
  isOpen: boolean;
}
interface StatCardProps {
  title: string;
  value: string;
  change: string;
  icon: React.ReactNode;
  color: string;
}
interface ScraperViewProps {
  groupUrl: string;
  setGroupUrl: (v: string) => void;
  isScraping: boolean;
  setIsScraping: (v: boolean) => void;
}
interface PageHeaderProps {
  title: string;
  description: string;
  children?: React.ReactNode;
}

/* ───────── Mock Data ───────── */
const chartData = [
  { name: 'شنبه', count: 400 },
  { name: 'یکشنبه', count: 600 },
  { name: 'دوشنبه', count: 900 },
  { name: 'سه‌شنبه', count: 1200 },
  { name: 'چهارشنبه', count: 1500 },
  { name: 'پنجشنبه', count: 2100 },
  { name: 'جمعه', count: 2400 },
];

const mockMembers = [
  { id: 1, username: '@alex_dev', name: 'Alex Johnson', status: 'Active', joined: '2024-10-01' },
  { id: 2, username: '@sarah_k', name: 'Sarah King', status: 'Recently Seen', joined: '2024-10-05' },
  { id: 3, username: '@mike_ross', name: 'Michael Ross', status: 'Offline', joined: '2024-10-10' },
  { id: 4, username: '@emma_w', name: 'Emma Wilson', status: 'Active', joined: '2024-10-12' },
  { id: 5, username: '@john_doe', name: 'John Doe', status: 'Active', joined: '2024-10-15' },
  { id: 6, username: '@lisa_m', name: 'Lisa Martin', status: 'Recently Seen', joined: '2024-10-18' },
  { id: 7, username: '@david_c', name: 'David Clark', status: 'Active', joined: '2024-10-20' },
  { id: 8, username: '@nina_p', name: 'Nina Patel', status: 'Offline', joined: '2024-10-22' },
];

const mockProxies = [
  { id: 1, host: '192.168.1.1', port: '8080', status: 'Online', type: 'HTTP', location: '🇺🇸 USA', latency: '42ms' },
  { id: 2, host: '172.16.0.45', port: '3128', status: 'Online', type: 'SOCKS5', location: '🇩🇪 Germany', latency: '68ms' },
  { id: 3, host: '45.12.33.102', port: '8888', status: 'Offline', type: 'HTTP', location: '🇬🇧 UK', latency: '—' },
  { id: 4, host: '103.24.77.19', port: '1080', status: 'Online', type: 'SOCKS5', location: '🇳🇱 Netherlands', latency: '55ms' },
];

const mockAccounts = [
  { phone: '+1 234 ••• 7890', name: 'Scraper Bot #1', status: 'Active', load: 45 },
  { phone: '+44 789 ••• 1234', name: 'Market Research', status: 'Active', load: 12 },
  { phone: '+49 152 ••• 5555', name: 'Lead Gen Unit', status: 'Paused', load: 0 },
];

/* ═══════════════════════════════════════════
   MAIN APP
   ═══════════════════════════════════════════ */
const App = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isScraping, setIsScraping] = useState(false);
  const [groupUrl, setGroupUrl] = useState('');

  const tabs: { key: string; label: string; icon: React.ReactNode }[] = [
    { key: 'dashboard', label: 'داشبورد', icon: <LayoutDashboard size={20} /> },
    { key: 'scraper', label: 'اسکرپر', icon: <Activity size={20} /> },
    { key: 'members', label: 'لیست اعضا', icon: <Users size={20} /> },
    { key: 'accounts', label: 'اکانت‌ها', icon: <Key size={20} /> },
    { key: 'proxies', label: 'پراکسی', icon: <Globe size={20} /> },
    { key: 'settings', label: 'تنظیمات', icon: <SettingsIcon size={20} /> },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <DashboardView />;
      case 'scraper': return <ScraperView groupUrl={groupUrl} setGroupUrl={setGroupUrl} isScraping={isScraping} setIsScraping={setIsScraping} />;
      case 'members': return <MembersView />;
      case 'accounts': return <AccountsView />;
      case 'proxies': return <ProxyView />;
      case 'settings': return <SettingsView />;
      default: return <DashboardView />;
    }
  };

  const currentTab = tabs.find(t => t.key === activeTab);

  return (
    <div className="flex h-screen bg-[#0a0f1e] text-slate-100 overflow-hidden">
      {/* ── Sidebar ── */}
      <aside className={`flex flex-col bg-[#111827] border-r border-white/5 transition-all duration-300 shrink-0 ${sidebarOpen ? 'w-60' : 'w-[72px]'}`}>
        {/* Logo */}
        <div className="h-16 flex items-center gap-3 px-5 border-b border-white/5">
          <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center shrink-0">
            <Zap size={20} className="text-white" />
          </div>
          {sidebarOpen && <span className="font-bold text-lg tracking-tight whitespace-nowrap">TeleScrape</span>}
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
          {tabs.map(tab => (
            <NavItem
              key={tab.key}
              icon={tab.icon}
              label={tab.label}
              active={activeTab === tab.key}
              onClick={() => setActiveTab(tab.key)}
              isOpen={sidebarOpen}
            />
          ))}
        </nav>

        {/* Toggle */}
        <div className="p-3 border-t border-white/5">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="w-full h-10 flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
          >
            {sidebarOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </aside>

      {/* ── Main ── */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="h-16 shrink-0 flex items-center justify-between px-6 bg-[#111827]/60 backdrop-blur-lg border-b border-white/5">
          <div className="flex items-center gap-2 text-sm">
            <span className="text-slate-500">پنل مدیریت</span>
            <ChevronRight size={14} className="text-slate-600" />
            <span className="font-medium">{currentTab?.label}</span>
          </div>
          <div className="flex items-center gap-3">
            <button className="relative p-2 rounded-lg hover:bg-white/5 text-slate-400 hover:text-white transition-colors">
              <Bell size={18} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
            </button>
            <div className="w-px h-6 bg-white/10" />
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-xs font-bold">
                AD
              </div>
              <span className="text-sm font-medium hidden md:block">Admin</span>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-6 custom-scrollbar">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.15 }}
              className="max-w-[1400px] mx-auto"
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
};

/* ═══════════════════════════════════════════
   SHARED COMPONENTS
   ═══════════════════════════════════════════ */
const NavItem = ({ icon, label, active, onClick, isOpen }: NavItemProps) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3 h-10 px-3 rounded-lg text-sm font-medium transition-all ${
      active
        ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
        : 'text-slate-400 hover:text-white hover:bg-white/5'
    }`}
  >
    <span className="shrink-0">{icon}</span>
    {isOpen && <span className="truncate">{label}</span>}
  </button>
);

const PageHeader = ({ title, description, children }: PageHeaderProps) => (
  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
    <div>
      <h1 className="text-xl font-bold">{title}</h1>
      <p className="text-sm text-slate-400 mt-1">{description}</p>
    </div>
    {children && <div className="flex items-center gap-3 shrink-0">{children}</div>}
  </div>
);

const Card = ({ children, className = '' }: { children: React.ReactNode; className?: string }) => (
  <div className={`bg-[#111827] rounded-xl border border-white/5 ${className}`}>
    {children}
  </div>
);

const StatCard = ({ title, value, change, icon, color }: StatCardProps) => (
  <Card className="p-5">
    <div className="flex items-start justify-between mb-4">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${color}`}>
        {icon}
      </div>
      <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
        change.startsWith('+') ? 'bg-emerald-500/10 text-emerald-400' : 'bg-blue-500/10 text-blue-400'
      }`}>
        {change}
      </span>
    </div>
    <p className="text-sm text-slate-400">{title}</p>
    <p className="text-2xl font-bold mt-0.5">{value}</p>
  </Card>
);

/* ═══════════════════════════════════════════
   DASHBOARD
   ═══════════════════════════════════════════ */
const DashboardView = () => (
  <div className="space-y-6">
    <PageHeader title="داشبورد" description="نمای کلی عملکرد اسکرپر و آمار استخراج اعضا" />

    {/* Stats */}
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <StatCard title="کل اعضای استخراج‌شده" value="12,482" change="+12%" icon={<Users size={20} className="text-blue-400" />} color="bg-blue-500/10" />
      <StatCard title="اسکرپ‌های فعال" value="3" change="Running" icon={<Activity size={20} className="text-emerald-400" />} color="bg-emerald-500/10" />
      <StatCard title="کانال‌های هدف" value="48" change="+5" icon={<MessageSquare size={20} className="text-purple-400" />} color="bg-purple-500/10" />
      <StatCard title="امتیاز ایمنی" value="98%" change="Optimal" icon={<ShieldCheck size={20} className="text-amber-400" />} color="bg-amber-500/10" />
    </div>

    {/* Chart + Side */}
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      {/* Chart */}
      <Card className="lg:col-span-2 p-5">
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-semibold">نمودار رشد هفتگی</h2>
          <select className="bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-xs outline-none">
            <option>۷ روز اخیر</option>
            <option>۳۰ روز اخیر</option>
          </select>
        </div>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
              <XAxis dataKey="name" stroke="#475569" tick={{ fontSize: 12 }} />
              <YAxis stroke="#475569" tick={{ fontSize: 12 }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: 8, fontSize: 12 }}
                itemStyle={{ color: '#f1f5f9' }}
              />
              <Area type="monotone" dataKey="count" stroke="#3b82f6" strokeWidth={2} fill="url(#grad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Card>

      {/* Activity */}
      <Card className="p-5 flex flex-col">
        <h2 className="font-semibold mb-4">فعالیت‌های اخیر</h2>
        <div className="flex-1 space-y-3">
          {[
            { text: '۱۵۰ عضو استخراج شد', sub: 'گروه Crypto Traders • ۲ ساعت پیش', icon: <Users size={16} /> },
            { text: 'خروجی CSV دانلود شد', sub: 'Marketing Leads • ۴ ساعت پیش', icon: <FileText size={16} /> },
            { text: 'اکانت جدید اضافه شد', sub: 'Scraper Bot #4 • دیروز', icon: <Key size={16} /> },
            { text: '۳۲۰ عضو استخراج شد', sub: 'Tech Community • دیروز', icon: <TrendingUp size={16} /> },
          ].map((item, i) => (
            <div key={i} className="flex items-start gap-3 p-3 rounded-lg hover:bg-white/[0.03] transition-colors">
              <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-blue-400 shrink-0 mt-0.5">
                {item.icon}
              </div>
              <div className="min-w-0">
                <p className="text-sm font-medium truncate">{item.text}</p>
                <p className="text-xs text-slate-500 mt-0.5 truncate">{item.sub}</p>
              </div>
            </div>
          ))}
        </div>
        <button className="mt-4 text-sm text-blue-400 hover:text-blue-300 font-medium text-center">مشاهده همه</button>
      </Card>
    </div>

    {/* Usage */}
    <Card className="p-5">
      <h2 className="font-semibold mb-5">مصرف امروز</h2>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <ProgressBar label="درخواست‌های API" current={840} total={1000} color="bg-blue-500" />
        <ProgressBar label="خروجی اعضا" current={42} total={50} color="bg-purple-500" />
        <ProgressBar label="نشست‌های فعال" current={3} total={5} color="bg-emerald-500" />
      </div>
    </Card>
  </div>
);

const ProgressBar = ({ label, current, total, color }: { label: string; current: number; total: number; color: string }) => (
  <div className="space-y-2">
    <div className="flex items-center justify-between text-sm">
      <span className="text-slate-400">{label}</span>
      <span className="font-medium">{current}<span className="text-slate-500">/{total}</span></span>
    </div>
    <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: `${(current / total) * 100}%` }}
        transition={{ duration: 0.8 }}
        className={`h-full rounded-full ${color}`}
      />
    </div>
  </div>
);

/* ═══════════════════════════════════════════
   SCRAPER
   ═══════════════════════════════════════════ */
const ScraperView = ({ groupUrl, setGroupUrl, isScraping, setIsScraping }: ScraperViewProps) => {
  const [logs, setLogs] = useState<{ id: number; time: string; msg: string; type: 'info' | 'success' | 'warning' | 'error' }[]>([
    { id: 1, time: '14:20:01', msg: 'سیستم آماده شد.', type: 'info' },
    { id: 2, time: '14:20:05', msg: 'منتظر ورود لینک گروه...', type: 'warning' },
  ]);

  const addLog = (msg: string, type: 'info' | 'success' | 'warning' | 'error' = 'info') => {
    const time = new Date().toLocaleTimeString('en-US', { hour12: false });
    setLogs(prev => [{ id: Date.now(), time, msg, type }, ...prev].slice(0, 50));
  };

  const handleStart = () => {
    if (!groupUrl) { addLog('خطا: لینک گروه وارد نشده.', 'error'); return; }
    setIsScraping(true);
    addLog(`شروع استخراج از ${groupUrl}...`, 'info');
    setTimeout(() => addLog('اتصال به API تلگرام موفق.', 'success'), 800);
    setTimeout(() => addLog('دریافت لیست اعضا...', 'info'), 1500);
    setTimeout(() => addLog('استخراج اعضا: ۱۰۰/۴۲۰۰...', 'info'), 2500);
  };

  const handleStop = () => {
    setIsScraping(false);
    addLog('عملیات اسکرپ توسط کاربر متوقف شد.', 'warning');
  };

  return (
    <div className="space-y-6">
      <PageHeader title="اسکرپر زنده" description="لینک گروه تلگرام را وارد کنید و استخراج اعضا را شروع کنید" />

      {/* Input Card */}
      <Card className="p-6">
        <div className="space-y-5">
          {/* URL + Button */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={groupUrl}
                onChange={e => setGroupUrl(e.target.value)}
                placeholder="https://t.me/groupname"
                className="w-full h-11 bg-white/5 border border-white/10 rounded-lg pl-10 pr-4 text-sm placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
              />
            </div>
            <button
              onClick={isScraping ? handleStop : handleStart}
              className={`h-11 px-6 rounded-lg font-bold text-sm flex items-center gap-2 shrink-0 transition-all ${
                isScraping
                  ? 'bg-red-500 hover:bg-red-600 text-white'
                  : 'bg-blue-600 hover:bg-blue-700 text-white'
              }`}
            >
              {isScraping ? <Square size={16} /> : <Play size={16} />}
              {isScraping ? 'توقف' : 'شروع اسکرپ'}
            </button>
          </div>

          {/* Options */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <SelectField label="سرعت اسکرپ" options={['محافظه‌کار (امن)', 'سریع (متعادل)', 'فوق‌العاده (پرریسک)']} />
            <SelectField label="فیلتر اعضا" options={['همه اعضا', 'فعال در ۲۴ ساعت اخیر', 'فعال در هفته اخیر']} />
            <SelectField label="فرمت خروجی" options={['JSON', 'CSV', 'TXT']} />
          </div>
        </div>
      </Card>

      {/* Console + Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Console */}
        <Card className="lg:col-span-2 overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3 border-b border-white/5">
            <span className="text-xs font-bold uppercase tracking-widest text-slate-500">کنسول</span>
            <div className="flex gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
              <span className="w-2.5 h-2.5 rounded-full bg-yellow-500" />
              <span className="w-2.5 h-2.5 rounded-full bg-green-500" />
            </div>
          </div>
          <div className="p-4 h-60 overflow-y-auto font-mono text-xs space-y-1.5 custom-scrollbar" dir="ltr">
            {logs.map(log => (
              <div key={log.id} className="flex gap-2">
                <span className="text-slate-600 shrink-0">[{log.time}]</span>
                <span className={`shrink-0 ${
                  log.type === 'error' ? 'text-red-400' :
                  log.type === 'success' ? 'text-green-400' :
                  log.type === 'warning' ? 'text-yellow-400' :
                  'text-blue-400'
                }`}>{log.type.toUpperCase()}</span>
                <span className="text-slate-300">{log.msg}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Stats */}
        <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-sm mb-1">آمار لحظه‌ای</h3>
            <p className="text-xs text-blue-200">وضعیت فعلی عملیات</p>
          </div>
          <div className="mt-5 space-y-4">
            <div>
              <div className="flex items-center justify-between text-sm mb-1.5">
                <span className="text-blue-100">پیشرفت</span>
                <span className="font-bold">{isScraping ? '64%' : '0%'}</span>
              </div>
              <div className="h-2 bg-white/20 rounded-full overflow-hidden">
                <div className="h-full bg-white rounded-full transition-all duration-700" style={{ width: isScraping ? '64%' : '0%' }} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 pt-1">
              <div>
                <p className="text-[11px] text-blue-200">اسکن شده</p>
                <p className="text-xl font-bold">{isScraping ? '2,140' : '—'}</p>
              </div>
              <div>
                <p className="text-[11px] text-blue-200">استخراج شده</p>
                <p className="text-xl font-bold">{isScraping ? '1,482' : '—'}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const SelectField = ({ label, options }: { label: string; options: string[] }) => (
  <div className="space-y-1.5">
    <label className="text-xs font-medium text-slate-400">{label}</label>
    <select className="w-full h-10 bg-white/5 border border-white/10 rounded-lg px-3 text-sm outline-none focus:ring-2 focus:ring-blue-500/50 appearance-none">
      {options.map(o => <option key={o}>{o}</option>)}
    </select>
  </div>
);

/* ═══════════════════════════════════════════
   MEMBERS
   ═══════════════════════════════════════════ */
const MembersView = () => (
  <div className="space-y-6">
    <PageHeader title="لیست اعضا" description="اعضای استخراج‌شده از گروه‌های تلگرام">
      <button className="h-10 px-4 rounded-lg bg-white/5 border border-white/10 text-sm font-medium flex items-center gap-2 hover:bg-white/10 transition-colors">
        <Download size={16} />
        خروجی گرفتن
      </button>
    </PageHeader>

    {/* Search */}
    <Card className="p-4">
      <div className="relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
        <input
          type="text"
          placeholder="جستجوی یوزرنیم یا نام..."
          className="w-full h-10 bg-white/5 border border-white/10 rounded-lg pl-10 pr-4 text-sm placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
        />
      </div>
    </Card>

    {/* Table */}
    <Card className="overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead>
            <tr className="border-b border-white/5 bg-white/[0.02]">
              <th className="px-5 py-3.5 text-xs font-semibold text-slate-400 uppercase tracking-wider">کاربر</th>
              <th className="px-5 py-3.5 text-xs font-semibold text-slate-400 uppercase tracking-wider">یوزرنیم</th>
              <th className="px-5 py-3.5 text-xs font-semibold text-slate-400 uppercase tracking-wider">وضعیت</th>
              <th className="px-5 py-3.5 text-xs font-semibold text-slate-400 uppercase tracking-wider">تاریخ عضویت</th>
              <th className="px-5 py-3.5 text-xs font-semibold text-slate-400 uppercase tracking-wider text-center">عملیات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {mockMembers.map(m => (
              <tr key={m.id} className="hover:bg-white/[0.02] transition-colors">
                <td className="px-5 py-3.5">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-xs font-bold text-slate-300">
                      {m.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <span className="font-medium">{m.name}</span>
                  </div>
                </td>
                <td className="px-5 py-3.5 text-blue-400 font-mono text-xs">{m.username}</td>
                <td className="px-5 py-3.5">
                  <StatusBadge status={m.status} />
                </td>
                <td className="px-5 py-3.5 text-slate-400">{m.joined}</td>
                <td className="px-5 py-3.5 text-center">
                  <button className="p-1.5 rounded-md hover:bg-white/5 text-slate-500 hover:text-white transition-colors">
                    <MessageSquare size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {/* Pagination */}
      <div className="flex items-center justify-between px-5 py-3 border-t border-white/5">
        <span className="text-xs text-slate-500">نمایش ۱-۸ از ۱۲,۴۸۲ عضو</span>
        <div className="flex gap-1">
          {[1, 2, 3, '...', 128].map((p, i) => (
            <button key={i} className={`w-8 h-8 rounded-md text-xs font-medium transition-colors ${
              p === 1 ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-white/5'
            }`}>{p}</button>
          ))}
        </div>
      </div>
    </Card>
  </div>
);

const StatusBadge = ({ status }: { status: string }) => {
  const config: Record<string, string> = {
    'Active': 'bg-emerald-500/10 text-emerald-400',
    'Recently Seen': 'bg-yellow-500/10 text-yellow-400',
    'Offline': 'bg-slate-500/10 text-slate-400',
  };
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold ${config[status] || config['Offline']}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${
        status === 'Active' ? 'bg-emerald-400' : status === 'Recently Seen' ? 'bg-yellow-400' : 'bg-slate-400'
      }`} />
      {status}
    </span>
  );
};

/* ═══════════════════════════════════════════
   ACCOUNTS
   ═══════════════════════════════════════════ */
const AccountsView = () => (
  <div className="space-y-6">
    <PageHeader title="مدیریت اکانت‌ها" description="مدیریت نشست‌های تلگرام برای توزیع بار اسکرپ">
      <button className="h-10 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 text-sm font-bold flex items-center gap-2 transition-colors">
        <Plus size={16} />
        افزودن اکانت
      </button>
    </PageHeader>

    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {mockAccounts.map((acc, i) => (
        <Card key={i} className="p-5 relative overflow-hidden group">
          <div className="absolute -top-4 -right-4 opacity-[0.03] group-hover:opacity-[0.06] transition-opacity">
            <Key size={80} />
          </div>
          <div className="relative space-y-4">
            {/* Status */}
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${acc.status === 'Active' ? 'bg-emerald-400' : 'bg-slate-500'}`} />
              <span className="text-[11px] font-bold uppercase tracking-widest text-slate-500">{acc.status}</span>
            </div>
            {/* Info */}
            <div>
              <h3 className="font-bold">{acc.name}</h3>
              <p className="text-sm text-slate-500 font-mono mt-0.5">{acc.phone}</p>
            </div>
            {/* Load */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-500">بار نشست</span>
                <span className="text-slate-300 font-medium">{acc.load}%</span>
              </div>
              <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500 rounded-full transition-all" style={{ width: `${acc.load}%` }} />
              </div>
            </div>
            {/* Actions */}
            <div className="flex gap-2 pt-1">
              <button className="flex-1 h-9 rounded-lg bg-white/5 border border-white/10 text-xs font-medium hover:bg-white/10 transition-colors">
                تنظیمات
              </button>
              <button className="flex-1 h-9 rounded-lg bg-white/5 border border-white/10 text-xs font-medium hover:bg-white/10 transition-colors">
                لاگ‌ها
              </button>
            </div>
          </div>
        </Card>
      ))}
    </div>
  </div>
);

/* ═══════════════════════════════════════════
   PROXY
   ═══════════════════════════════════════════ */
const ProxyView = () => (
  <div className="space-y-6">
    <PageHeader title="مدیریت پراکسی" description="مدیریت لیست پراکسی‌ها برای جلوگیری از محدودیت IP">
      <button className="h-10 px-4 rounded-lg bg-white/5 border border-white/10 text-sm font-medium flex items-center gap-2 hover:bg-white/10 transition-colors">
        <RefreshCw size={16} />
        بررسی همه
      </button>
      <button className="h-10 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 text-sm font-bold flex items-center gap-2 transition-colors">
        <Plus size={16} />
        افزودن پراکسی
      </button>
    </PageHeader>

    <Card className="overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead>
            <tr className="border-b border-white/5 bg-white/[0.02]">
              <th className="px-5 py-3.5 text-xs font-semibold text-slate-400 uppercase tracking-wider">Host:Port</th>
              <th className="px-5 py-3.5 text-xs font-semibold text-slate-400 uppercase tracking-wider">نوع</th>
              <th className="px-5 py-3.5 text-xs font-semibold text-slate-400 uppercase tracking-wider">موقعیت</th>
              <th className="px-5 py-3.5 text-xs font-semibold text-slate-400 uppercase tracking-wider">تأخیر</th>
              <th className="px-5 py-3.5 text-xs font-semibold text-slate-400 uppercase tracking-wider">وضعیت</th>
              <th className="px-5 py-3.5 text-xs font-semibold text-slate-400 uppercase tracking-wider text-center">عملیات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {mockProxies.map(p => (
              <tr key={p.id} className="hover:bg-white/[0.02] transition-colors">
                <td className="px-5 py-3.5 font-mono text-xs">{p.host}:{p.port}</td>
                <td className="px-5 py-3.5">
                  <span className="px-2 py-0.5 rounded bg-white/5 text-[11px] font-bold">{p.type}</span>
                </td>
                <td className="px-5 py-3.5">{p.location}</td>
                <td className="px-5 py-3.5 text-slate-400 font-mono text-xs">{p.latency}</td>
                <td className="px-5 py-3.5">
                  <StatusBadge status={p.status === 'Online' ? 'Active' : 'Offline'} />
                </td>
                <td className="px-5 py-3.5 text-center">
                  <button className="p-1.5 rounded-md hover:bg-red-500/10 text-slate-500 hover:text-red-400 transition-colors">
                    <Trash2 size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>

    {/* Notice */}
    <Card className="p-4 flex items-start gap-4">
      <div className="w-9 h-9 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400 shrink-0">
        <ShieldCheck size={18} />
      </div>
      <div>
        <p className="text-sm font-medium">چرخش خودکار فعال است</p>
        <p className="text-xs text-slate-500 mt-0.5">اسکرپر هر ۱۰۰ درخواست به‌صورت خودکار بین پراکسی‌های آنلاین جابه‌جا می‌شود.</p>
      </div>
    </Card>
  </div>
);

/* ═══════════════════════════════════════════
   SETTINGS
   ═══════════════════════════════════════════ */
const SettingsView = () => {
  const [autoExport, setAutoExport] = useState(true);
  const [stealth, setStealth] = useState(false);

  return (
    <div className="space-y-6 max-w-2xl">
      <PageHeader title="تنظیمات" description="پیکربندی API و ترجیحات اسکرپر" />

      {/* API */}
      <Card className="p-6 space-y-5">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400">
            <ShieldCheck size={18} />
          </div>
          <h2 className="font-bold">احراز هویت API</h2>
        </div>

        <div className="space-y-4">
          <InputField label="Telegram API ID" placeholder="وارد کنید..." type="password" />
          <InputField label="Telegram API Hash" placeholder="وارد کنید..." type="password" />
          <InputField label="Bot Token (اختیاری)" placeholder="وارد کنید..." type="password" />
        </div>

        <button className="w-full h-11 bg-blue-600 hover:bg-blue-700 rounded-lg font-bold text-sm transition-colors">
          ذخیره اطلاعات
        </button>
      </Card>

      {/* Preferences */}
      <Card className="p-6 space-y-5">
        <h2 className="font-bold">ترجیحات</h2>

        <div className="space-y-1">
          <ToggleRow
            title="خروجی خودکار"
            description="پس از اتمام اسکرپ، فایل CSV خودکار دانلود شود"
            active={autoExport}
            onToggle={() => setAutoExport(!autoExport)}
          />
          <div className="border-t border-white/5" />
          <ToggleRow
            title="حالت مخفی"
            description="استفاده از تأخیر تصادفی و چرخش پراکسی"
            active={stealth}
            onToggle={() => setStealth(!stealth)}
          />
        </div>
      </Card>
    </div>
  );
};

const InputField = ({ label, placeholder, type = 'text' }: { label: string; placeholder: string; type?: string }) => (
  <div className="space-y-1.5">
    <label className="text-xs font-medium text-slate-400">{label}</label>
    <input
      type={type}
      placeholder={placeholder}
      className="w-full h-11 bg-white/5 border border-white/10 rounded-lg px-4 text-sm placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
    />
  </div>
);

const ToggleRow = ({ title, description, active, onToggle }: { title: string; description: string; active: boolean; onToggle: () => void }) => (
  <div className="flex items-center justify-between py-3 gap-4">
    <div>
      <p className="text-sm font-medium">{title}</p>
      <p className="text-xs text-slate-500 mt-0.5">{description}</p>
    </div>
    <button
      onClick={onToggle}
      className={`w-11 h-6 rounded-full relative shrink-0 transition-colors ${active ? 'bg-blue-600' : 'bg-white/10'}`}
    >
      <span className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${active ? 'right-1' : 'left-1'}`} />
    </button>
  </div>
);

export default App;
